<?php
define('App', true);
$mff = new MFF();
$hereisflag = file_get_contents('/flag'); //can you catch me?
$mff->run();
