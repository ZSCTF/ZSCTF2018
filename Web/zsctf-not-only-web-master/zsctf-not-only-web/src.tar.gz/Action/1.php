<?php
if (!defined('App'))die();
?>
<!DOCTYPE html>
<html>
<head>
	<title>sample page</title>
</head>
<body>
	<h1>my_fast_framework sample site</h1>
	<ol>
		<li><a href="?action=1">Action 1</a></li>
		<li><a href="?action=2">Action 2</a></li>
	</ol>
	<h2>here is action 1</h2>
</body>
</html>