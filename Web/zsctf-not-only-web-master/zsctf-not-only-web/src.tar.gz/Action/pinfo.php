<?php
if (!defined('App'))die();
phpinfo();